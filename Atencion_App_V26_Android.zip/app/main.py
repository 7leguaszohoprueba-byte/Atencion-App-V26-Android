import os
import re
import threading
from datetime import datetime

from kivy.app import App
from kivy.clock import Clock
from kivy.core.window import Window
from kivy.metrics import dp
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.gridlayout import GridLayout
from kivy.uix.scrollview import ScrollView
from kivy.uix.screenmanager import ScreenManager, Screen, SlideTransition
from kivy.uix.label import Label
from kivy.uix.button import Button
from kivy.uix.textinput import TextInput
from kivy.uix.spinner import Spinner
from kivy.uix.checkbox import CheckBox
from kivy.uix.popup import Popup
from kivy.uix.widget import Widget
from kivy.properties import StringProperty, BooleanProperty

from db import *
from auth import authenticate, hash_password

init_db()

BG = (0.055, 0.065, 0.08, 1)
SURFACE = (0.09, 0.105, 0.13, 1)
SURFACE2 = (0.12, 0.14, 0.18, 1)
FG = (0.94, 0.95, 0.98, 1)
MUTED = (0.65, 0.68, 0.75, 1)
ACCENT = (0.38, 0.48, 1, 1)
DANGER = (0.85, 0.28, 0.3, 1)
BORDER = (0.18, 0.21, 0.27, 1)


def btn(text, callback, kind="secondary", h=dp(46)):
    b = Button(text=text, size_hint_y=None, height=h, background_normal="", background_down="",
               color=FG, font_size=dp(14))
    b.background_color = ACCENT if kind == "accent" else (DANGER if kind == "danger" else SURFACE2)
    b.bind(on_release=lambda *_: callback())
    return b


def label(text, size=14, color=FG, bold=False, halign="left"):
    l = Label(text=text, size_hint_y=None, height=dp(28), color=color, font_size=dp(size),
              bold=bold, halign=halign, valign="middle")
    l.bind(size=lambda w, v: setattr(w, 'text_size', (w.width, None)))
    return l


def field(text="", password=False, multiline=False, h=dp(44)):
    w = TextInput(text=text, multiline=multiline, password=password, size_hint_y=None, height=h,
                  background_normal="", background_active="", background_color=SURFACE2,
                  foreground_color=FG, cursor_color=ACCENT, padding=[dp(12), dp(10)], font_size=dp(14))
    return w


def card(parent, padding=dp(12)):
    box = BoxLayout(orientation="vertical", padding=padding, spacing=dp(8), size_hint_y=None)
    box.bind(minimum_height=box.setter('height'))
    parent.add_widget(box)
    return box


def scroll_container():
    s = ScrollView(do_scroll_x=False, bar_width=dp(8))
    inner = GridLayout(cols=1, spacing=dp(10), padding=[dp(10), dp(10)], size_hint_y=None)
    inner.bind(minimum_height=inner.setter('height'))
    s.add_widget(inner)
    return s, inner


def popup(title, message, buttons=None, size=(0.92, 0.48)):
    body = BoxLayout(orientation="vertical", padding=dp(18), spacing=dp(12))
    body.add_widget(label(title, 18, FG, True))
    msg = Label(text=str(message), color=FG, font_size=dp(13), halign="left", valign="top")
    msg.bind(size=lambda w, v: setattr(w, 'text_size', (w.width, None)))
    body.add_widget(msg)
    row = BoxLayout(size_hint_y=None, height=dp(46), spacing=dp(8))
    buttons = buttons or [("Aceptar", "secondary")]
    p = Popup(title="", content=body, size_hint=size, separator_height=0, background_color=SURFACE)
    for text, kind in buttons:
        row.add_widget(btn(text, p.dismiss, kind))
    body.add_widget(row)
    p.open(); return p


class Base(Screen):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.body = BoxLayout(orientation="vertical")
        self.add_widget(self.body)

    def clear(self): self.body.clear_widgets()

    def title(self, text, subtitle=None, back=True):
        bar = BoxLayout(size_hint_y=None, height=dp(64), padding=[dp(14), dp(8)], spacing=dp(10))
        if back:
            bar.add_widget(btn("‹", lambda: app().home(), "secondary", dp(46)))
        t = BoxLayout(orientation="vertical")
        t.add_widget(label(text, 19, FG, True))
        if subtitle: t.add_widget(label(subtitle, 11, MUTED))
        bar.add_widget(t)
        self.body.add_widget(bar)

    def content_scroll(self):
        return scroll_container()


def app(): return App.get_running_app()


class SetupScreen(Base):
    def on_pre_enter(self, *args):
        self.clear()
        self.title("Configuración inicial", "Selecciona la sucursal de esta computadora.", False)
        s, inner = self.content_scroll(); self.body.add_widget(s)
        box = card(inner, dp(16))
        box.add_widget(label("Sucursal", 13, MUTED))
        branch = Spinner(text=SUCURSALES[0], values=SUCURSALES, size_hint_y=None, height=dp(46),
                         background_normal="", background_color=SURFACE2, color=FG)
        box.add_widget(branch)
        box.add_widget(label("Administrador", 13, MUTED)); user = field(); box.add_widget(user)
        box.add_widget(label("Contraseña", 13, MUTED)); pw = field(password=True); box.add_widget(pw)
        box.add_widget(label("Confirmar contraseña", 13, MUTED)); pw2 = field(password=True); box.add_widget(pw2)
        box.add_widget(label("Esta configuración queda asociada al dispositivo. La sucursal también se aplica automáticamente a las importaciones de Excel.", 12, MUTED))
        def save():
            if not user.text.strip() or len(pw.text) < 6: return popup("Datos incompletos", "Indica usuario y una contraseña de al menos 6 caracteres.")
            if pw.text != pw2.text: return popup("Contraseña", "Las contraseñas no coinciden.")
            try:
                create_user(user.text.strip(), hash_password(pw.text), "admin")
                set_config("sucursal", branch.text); set_config("setup_complete", "1")
                popup("Listo", "Configuración guardada.", [("Continuar", "accent")]).bind(on_dismiss=lambda *_: app().home())
            except Exception as e: popup("Error", e)
        box.add_widget(btn("Guardar configuración", save, "accent"))


class HomeScreen(Base):
    def on_pre_enter(self, *args):
        self.clear()
        head = BoxLayout(size_hint_y=None, height=dp(82), padding=[dp(18), dp(12)])
        t = BoxLayout(orientation="vertical")
        t.add_widget(label("Atención V26", 22, FG, True)); t.add_widget(label(get_config("sucursal", "Sin sucursal"), 12, MUTED))
        head.add_widget(t); self.body.add_widget(head)
        grid = GridLayout(cols=2, spacing=dp(10), padding=[dp(14), dp(8)], size_hint_y=None)
        grid.bind(minimum_height=grid.setter('height'))
        actions = [
            ("＋  Nuevo registro", lambda: app().go("new"), "accent"),
            ("☰  Ver registros", lambda: app().go("review"), "secondary"),
            ("⇧  Subir a Zoho", self.sync, "secondary"),
            ("⚙  Configuración", lambda: app().go("settings"), "secondary"),
        ]
        for text, cb, kind in actions: grid.add_widget(btn(text, cb, kind, dp(100)))
        self.body.add_widget(grid)
        self.body.add_widget(Widget())
        self.body.add_widget(label("Los registros nuevos se guardan primero en el dispositivo y después pueden sincronizarse con Zoho.", 12, MUTED))
        self.body.add_widget(Widget(size_hint_y=None, height=dp(10)))

    def sync(self):
        app().sync_zoho()

    def _sync_with_user(self, user):
        if not user:
            return
        def work():
            try:
                from sync_zoho import sync_pending
                result = sync_pending()
            except Exception as e:
                result = f"No fue posible sincronizar:\n{e}"
            Clock.schedule_once(lambda *_: popup("Sincronización", result), 0)
        threading.Thread(target=work, daemon=True).start()


class NewRecordScreen(Base):
    def on_pre_enter(self, *args):
        self.clear(); self.title("Nuevo registro", "Los campos marcados con * son obligatorios.")
        s, inner = self.content_scroll(); self.body.add_widget(s); box = card(inner, dp(14))
        sin = CheckBox(size_hint=(None, None), size=(dp(36), dp(36))); row = BoxLayout(size_hint_y=None, height=dp(40))
        row.add_widget(sin); row.add_widget(label("Sin Datos", 14, FG, True)); box.add_widget(row)
        entries = {}
        for key, text, pw in [("cliente","Cliente",False),("telefono","Teléfono",False),("email","Correo electrónico",False),("atendio","Atendió *",False),("solicitud","Solicitud *",False),("necesidades","Necesidades adicionales",False),("informacion","Información",False)]:
            box.add_widget(label(text, 12, MUTED)); e = field(multiline=(key=="informacion"), h=dp(100) if key=="informacion" else dp(44)); box.add_widget(e); entries[key]=e
        box.add_widget(label("Tipo", 12, MUTED)); tipo = Spinner(text="Producto", values=["Producto","Servicio","Otro"], size_hint_y=None, height=dp(46), background_normal="", background_color=SURFACE2, color=FG); box.add_widget(tipo)
        box.add_widget(label("Sucursal", 12, MUTED)); branch = field(get_config("sucursal", "")); branch.readonly = True; box.add_widget(branch)
        def toggle(_a, _b):
            disabled = bool(sin.active)
            for k in ("cliente","telefono","email"):
                entries[k].disabled = disabled
                if disabled: entries[k].text = ""
        sin.bind(active=toggle)
        def save():
            if not entries["atendio"].text.strip() or not entries["solicitud"].text.strip(): return popup("Falta información", "Atendió y Solicitud son obligatorios.")
            save_interaction({"cliente":entries["cliente"].text.strip(),"telefono":entries["telefono"].text.strip(),"email":entries["email"].text.strip(),"atendio":entries["atendio"].text.strip(),"sucursal":get_config("sucursal",""),"tipo":tipo.text,"solicitud":entries["solicitud"].text.strip(),"necesidades":entries["necesidades"].text.strip(),"informacion":entries["informacion"].text.strip(),"sin_datos":bool(sin.active)})
            popup("Guardado", "Registro guardado localmente.", [("Aceptar", "accent")]).bind(on_dismiss=lambda *_: app().home())
        box.add_widget(btn("Guardar registro", save, "accent")); box.add_widget(btn("Cancelar", app().home))


class ReviewScreen(Base):
    def on_pre_enter(self, *args):
        self.build()
    def build(self):
        self.clear(); self.title("Registros", f"Sucursal: {get_config('sucursal','')}")
        controls = BoxLayout(orientation="vertical", size_hint_y=None, height=dp(300), padding=[dp(10),0], spacing=dp(6))
        search = field(); controls.add_widget(search)
        row1 = GridLayout(cols=2, spacing=dp(6), size_hint_y=None, height=dp(48))
        atend = field(); solicitud = field(); row1.add_widget(atend); row1.add_widget(solicitud); controls.add_widget(row1)
        row2 = GridLayout(cols=2, spacing=dp(6), size_hint_y=None, height=dp(48))
        tipo = Spinner(text="", values=["","Producto","Servicio","Otro"], background_normal="", background_color=SURFACE2, color=FG)
        estado = Spinner(text="", values=["", *ESTADOS_CONTACTO], background_normal="", background_color=SURFACE2, color=FG)
        row2.add_widget(tipo); row2.add_widget(estado); controls.add_widget(row2)
        row3 = GridLayout(cols=2, spacing=dp(6), size_hint_y=None, height=dp(48))
        desde = field(); hasta = field(); row3.add_widget(desde); row3.add_widget(hasta); controls.add_widget(row3)
        hints = GridLayout(cols=2, size_hint_y=None, height=dp(26)); hints.add_widget(label("Fecha desde (AAAA-MM-DD)",10,MUTED)); hints.add_widget(label("Fecha hasta (AAAA-MM-DD)",10,MUTED)); controls.add_widget(hints)
        self.body.add_widget(controls)
        list_scroll = ScrollView(do_scroll_x=False, bar_width=dp(8)); list_box = GridLayout(cols=1, spacing=dp(7), padding=[dp(10),0], size_hint_y=None); list_box.bind(minimum_height=list_box.setter('height')); list_scroll.add_widget(list_box); self.body.add_widget(list_scroll)
        bottom = BoxLayout(size_hint_y=None, height=dp(52), padding=[dp(10),dp(5)], spacing=dp(6)); self.body.add_widget(bottom)
        bottom.add_widget(btn("＋ Importar Excel", lambda: app().go("import"), "secondary")); bottom.add_widget(btn("↻ Actualizar", self.build, "secondary")); bottom.add_widget(btn("⇧ Sincronizar", lambda: app().sync_zoho(), "accent")); bottom.add_widget(btn("⬇ Exportar", self.export_visible, "secondary"))

        def render(*_):
            for child in list_box.children[:]: list_box.remove_widget(child)
            records = all_interactions(get_config("sucursal", ""))
            sq=search.text.strip().lower(); aq=atend.text.strip().lower(); rq=solicitud.text.strip().lower(); tq=tipo.text; eq=estado.text; fd=desde.text.strip(); fh=hasta.text.strip()
            try:
                if fd: datetime.strptime(fd,"%Y-%m-%d")
                if fh: datetime.strptime(fh,"%Y-%m-%d")
                if fd and fh and fd>fh: raise ValueError
            except ValueError:
                return
            shown=[]
            for r in records:
                hay=" ".join(str(x or "") for x in r[:10]).lower()
                day=(r[9] or "")[:10]
                if sq and sq not in hay: continue
                if aq and aq not in (r[3] or "").lower(): continue
                if rq and rq not in (r[6] or "").lower(): continue
                if tq and tq!=(r[5] or ""): continue
                if eq and eq!=(r[12] or ""): continue
                if fd and day<fd: continue
                if fh and day>fh: continue
                shown.append(r)
            for r in shown:
                status = "Consulta" if (r[14] or "Lead")=="Consulta" else "Lead"
                sync = "Sincronizado" if r[10] else f"Pendiente · {status}"
                b=Button(text=f"#{r[0]}  {r[1] or 'Sin datos'}\n{r[3]} · {r[5]} · {r[6]}\n{r[9]} · {r[12]} · {sync}", size_hint_y=None, height=dp(86), halign="left", valign="middle", background_normal="", background_color=SURFACE, color=FG, font_size=dp(12))
                b.bind(size=lambda w,v:setattr(w,'text_size',(w.width-dp(20),None)))
                b.bind(on_release=lambda _b, rid=r[0]: app().edit_record(rid))
                list_box.add_widget(b)
            self.visible_records = shown
            if not shown: list_box.add_widget(label("No hay registros con esos filtros.", 13, MUTED))
        for w in (search, atend, solicitud, desde, hasta): w.bind(text=render)
        tipo.bind(text=render); estado.bind(text=render); render()

    def export_visible(self):
        records = getattr(self, 'visible_records', [])
        if not records:
            return popup('Exportación', 'No hay registros visibles para exportar.')
        try:
            from openpyxl import Workbook
            from io import BytesIO
            wb=Workbook(); ws=wb.active; ws.title='Registros'
            headers=['ID','Cliente','Teléfono','Correo','Atendió','Tipo','Solicitud','Necesidades adicionales','Información','Fecha de registro','Estado de contacto','Situación Zoho']
            ws.append(headers)
            for r in records:
                ws.append([r[0],r[1],r[2],r[13],r[3],r[5],r[6],r[7],r[8],r[9],r[12], 'Consulta' if (r[14] or 'Lead')=='Consulta' else 'Lead' if r[10] else f"Pendiente · {'Consulta' if (r[14] or 'Lead')=='Consulta' else 'Lead'}"])
            ws.freeze_panes='A2'; ws.auto_filter.ref=ws.dimensions
            bio=BytesIO(); wb.save(bio); data=bio.getvalue()
            from file_bridge import save_bytes
            filename='Atencion_V26_registros.xlsx'
            save_bytes(filename,data,'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',lambda ok: popup('Exportación','Archivo guardado correctamente.' if ok else 'No se pudo guardar el archivo.'))
        except Exception as e:
            popup('Exportación',e)


class ImportScreen(Base):
    def on_pre_enter(self, *args): self.reset()
    def reset(self):
        self.clear(); self.title("Importar registros", "Mapea las columnas del Excel antes de importar.")
        top = BoxLayout(size_hint_y=None, height=dp(52), padding=[dp(10),0], spacing=dp(6)); self.body.add_widget(top)
        self.status=label("Ningún archivo seleccionado.",12,MUTED); top.add_widget(self.status); top.add_widget(btn("Seleccionar Excel", self.pick, "accent"))
        self.main_scroll, self.main_inner = scroll_container(); self.body.add_widget(self.main_scroll)
        self.map_data=[]; self.file_path=None; self.sheet=None; self.header_row=1; self.headers=[]; self.preview_rows=[]
        self.load_btn=btn("Importar registros", self.do_import, "accent"); self.load_btn.disabled=True; self.body.add_widget(self.load_btn)
    def pick(self):
        from file_bridge import open_xlsx
        open_xlsx(self.loaded)
    def loaded(self, path):
        if not path: return popup("Importación", "No se pudo abrir el archivo.")
        self.file_path=path
        try:
            from openpyxl import load_workbook
            wb=load_workbook(path, read_only=True, data_only=True)
            self.wb=wb; self.sheet=wb.active
            self.show_mapping()
        except Exception as e: popup("Excel", f"No se pudo leer el archivo:\n{e}")
    def show_mapping(self):
        self.main_inner.clear_widgets(); self.status.text=f"Archivo: {os.path.basename(self.file_path)}"
        opts=card(self.main_inner, dp(12)); opts.add_widget(label("Hoja",12,MUTED));
        sheet_names=self.wb.sheetnames; self.sheet_spinner=Spinner(text=self.sheet.title, values=sheet_names, size_hint_y=None,height=dp(44),background_normal="",background_color=SURFACE2,color=FG); opts.add_widget(self.sheet_spinner)
        opts.add_widget(label("Fila de encabezados",12,MUTED)); self.header_spinner=Spinner(text="1",values=[str(i) for i in range(1,31)],size_hint_y=None,height=dp(44),background_normal="",background_color=SURFACE2,color=FG); opts.add_widget(self.header_spinner)
        self.header_spinner.bind(text=lambda *_: self.refresh_preview()); self.sheet_spinner.bind(text=lambda *_: self.refresh_preview())
        self.refresh_preview()
    def refresh_preview(self):
        if not hasattr(self,'wb'): return
        self.sheet=self.wb[self.sheet_spinner.text]; self.header_row=int(self.header_spinner.text)
        rows=self.sheet.iter_rows(min_row=self.header_row,max_row=self.header_row+6,values_only=True); rows=list(rows)
        if not rows: return
        self.headers=[str(x or f"Columna {i+1}") for i,x in enumerate(rows[0])]
        self.preview_rows=rows[1:]
        # Las columnas se muestran horizontalmente; encima de cada una queda su selector.
        self.main_inner.clear_widgets()
        self.main_inner.add_widget(label("Selecciona qué representa cada columna del Excel. Sucursal no se importa: siempre será la sucursal configurada en este dispositivo.",12,MUTED))
        choices=["— No importar —","Cliente","Teléfono","Correo","Atendió","Tipo","Solicitud","Necesidades adicionales","Información","Estado de contacto","Fecha de registro"]
        grid=GridLayout(cols=len(self.headers), spacing=dp(5), size_hint_x=None, size_hint_y=None, padding=[dp(5),dp(5)])
        colw=dp(155); grid.width=max(dp(330),colw*len(self.headers)); grid.bind(minimum_height=grid.setter('height'))
        vars=[]
        for i,h in enumerate(self.headers):
            c=BoxLayout(orientation='vertical', size_hint=(None,None), width=colw, height=dp(300), spacing=dp(5))
            c.add_widget(label(f"Columna {i+1}",10,MUTED)); sp=Spinner(text=self.auto_map(h),values=choices,size_hint_y=None,height=dp(44),background_normal="",background_color=SURFACE2,color=FG); c.add_widget(sp); c.add_widget(label(h,12,FG,True));
            for rr in self.preview_rows: c.add_widget(label(str(rr[i] if i<len(rr) and rr[i] is not None else ""),10,MUTED))
            vars.append(sp); grid.add_widget(c)
        hs=ScrollView(do_scroll_y=False,bar_width=dp(8),size_hint_y=None,height=dp(330)); hs.add_widget(grid); self.main_inner.add_widget(hs); self.map_vars=vars; self.load_btn.disabled=False
    def auto_map(self,h):
        n=re.sub(r"[^a-z0-9]","",str(h).lower().replace("á","a").replace("é","e").replace("í","i").replace("ó","o").replace("ú","u").replace("ñ","n"))
        aliases={"cliente":"Cliente","nombre":"Cliente","telefono":"Teléfono","celular":"Teléfono","phone":"Teléfono","correo":"Correo","email":"Correo","mail":"Correo","atendio":"Atendió","asesor":"Atendió","vendedor":"Atendió","tipo":"Tipo","solicitud":"Solicitud","necesidades":"Necesidades adicionales","informacion":"Información","estado":"Estado de contacto","estadodecontacto":"Estado de contacto","fecha":"Fecha de registro","fecharegistro":"Fecha de registro"}
        return aliases.get(n,"— No importar —")
    def do_import(self):
        if not self.file_path: return
        choices=["— No importar —","Cliente","Teléfono","Correo","Atendió","Tipo","Solicitud","Necesidades adicionales","Información","Estado de contacto","Fecha de registro"]
        selected={}; duplicates=set()
        for i,sp in enumerate(self.map_vars):
            val=sp.text
            if val in choices[1:]:
                if val in selected: duplicates.add(val)
                selected[val]=i
        if duplicates: return popup("Mapeo", "No puedes asignar el mismo campo a dos columnas: " + ", ".join(sorted(duplicates)))
        def work():
            try:
                from openpyxl import load_workbook
                wb=load_workbook(self.file_path,read_only=True,data_only=True); ws=wb[self.sheet_spinner.text]; hr=int(self.header_spinner.text)
                rows=[]
                for rn,row in enumerate(ws.iter_rows(min_row=hr+1,values_only=True),hr+1):
                    def v(k):
                        idx=selected.get(k); return "" if idx is None or idx>=len(row) or row[idx] is None else str(row[idx]).strip()
                    dateval=row[selected['Fecha de registro']] if 'Fecha de registro' in selected and selected['Fecha de registro']<len(row) else None
                    if hasattr(dateval,'strftime'): dateval=dateval.strftime('%Y-%m-%d %H:%M:%S')
                    vals={'cliente':v('Cliente'),'telefono':v('Teléfono'),'email':v('Correo'),'atendio':v('Atendió'),'tipo':v('Tipo'),'solicitud':v('Solicitud'),'necesidades':v('Necesidades adicionales'),'informacion':v('Información'),'estado_contacto':v('Estado de contacto'),'fecha':dateval or v('Fecha de registro')}
                    rows.append((rn,vals))
                result=save_imported_rows(rows,get_config('sucursal',''))
            except Exception as e: result=(0,0,[str(e)])
            Clock.schedule_once(lambda *_: self.finish(result),0)
        threading.Thread(target=work,daemon=True).start()
    def finish(self,result):
        imp,skip,errors=result; popup("Importación",f"Importados: {imp}\nOmitidos: {skip}" + ("\n\n"+"\n".join(errors[:8]) if errors else ""),[("Aceptar","accent")]).bind(on_dismiss=lambda *_: app().go("review"))


class SettingsScreen(Base):
    def on_pre_enter(self,*args):
        self.clear(); self.title("Configuración", "Apariencia, administración y sucursal de este dispositivo.")
        s,inner=self.content_scroll(); self.body.add_widget(s)
        box=card(inner); box.add_widget(label("Sucursal actual",13,MUTED)); box.add_widget(label(get_config('sucursal',''),16,FG,True)); box.add_widget(label("La sucursal se mantiene desde Administración y se aplica a registros e importaciones.",11,MUTED)); box.add_widget(btn("Administración",lambda: app().go('admin'),"accent")); box.add_widget(btn("Cerrar sesión de administrador",app().logout_admin));


class AdminScreen(Base):
    def on_pre_enter(self, *args):
        if app().admin_user:
            self.user = app().admin_user
            self.build()
        else:
            app().request_login("Acceso a administración", self._after_login)

    def _after_login(self, user):
        if not user:
            return app().go('settings')
        self.user = user
        app().admin_user = user
        self.build()

    def build(self):
        self.clear(); self.title("Administración", f"Sucursal actual: {get_config('sucursal','')}")
        s,inner=self.content_scroll(); self.body.add_widget(s)
        box=card(inner)
        box.add_widget(label("Sucursal",15,FG,True))
        branch=Spinner(text=get_config('sucursal',''),values=SUCURSALES,size_hint_y=None,height=dp(46),background_normal='',background_color=SURFACE2,color=FG)
        box.add_widget(branch)
        def save_branch():
            set_config('sucursal', branch.text); popup('Sucursal','Sucursal actualizada correctamente.')
        box.add_widget(btn('Guardar sucursal',save_branch,'secondary'))
        box.add_widget(label("Modo administrador",15,FG,True))
        mode=CheckBox(active=bool(app().admin_mode),size_hint=(None,None),size=(dp(40),dp(40))); row=BoxLayout(size_hint_y=None,height=dp(42)); row.add_widget(mode); row.add_widget(label("Activar modo administrador",13,FG)); box.add_widget(row)
        def toggle(_w,val):
            if val and self.user.get('rol')!='admin':
                mode.active=False; return popup('Permisos','Solo un administrador puede activar este modo.')
            app().admin_mode=bool(val); app().admin_user=self.user
        mode.bind(active=toggle)
        box.add_widget(label("Usuarios gerentes",15,FG,True))
        u=field(); p=field(password=True); box.add_widget(label('Usuario',12,MUTED)); box.add_widget(u); box.add_widget(label('Contraseña',12,MUTED)); box.add_widget(p)
        box.add_widget(btn('Agregar gerente',lambda:self.add_manager(u,p),'accent'))
        for r in list_users():
            line=BoxLayout(size_hint_y=None,height=dp(42),spacing=dp(6)); line.add_widget(label(f"#{r[0]}  {r[1]} · {r[2]} · {'Activo' if r[3] else 'Inactivo'}",12,MUTED));
            if r[3]: line.add_widget(btn('Desactivar',lambda rid=r[0]: self.toggle_user(rid,False),'danger',dp(38)))
            else: line.add_widget(btn('Activar',lambda rid=r[0]: self.toggle_user(rid,True),'secondary',dp(38)))
            box.add_widget(line)
        box.add_widget(label("Credenciales de Zoho",15,FG,True)); z={k:field(get_config(k,''), password=('SECRET' in k or 'TOKEN' in k)) for k in ['ZOHO_CLIENT_ID','ZOHO_CLIENT_SECRET','ZOHO_REFRESH_TOKEN','ZOHO_API_DOMAIN','ZOHO_ACCOUNTS_DOMAIN']}
        names={'ZOHO_CLIENT_ID':'Client ID','ZOHO_CLIENT_SECRET':'Client secret','ZOHO_REFRESH_TOKEN':'Refresh token','ZOHO_API_DOMAIN':'Dominio de la API','ZOHO_ACCOUNTS_DOMAIN':'Dominio de cuentas'}
        for k,e in z.items(): box.add_widget(label(names[k],12,MUTED)); box.add_widget(e)
        box.add_widget(btn('Guardar credenciales Zoho',lambda:self.save_zoho(z),'accent'))
        box.add_widget(btn('Cerrar modo administrador',app().logout_admin,'secondary'))
    def add_manager(self,u,p):
        if not u.text.strip() or len(p.text)<6: return popup('Usuario','Indica usuario y contraseña de al menos 6 caracteres.')
        try:
            create_user(u.text.strip(),hash_password(p.text),'gerente'); popup('Usuario','Gerente creado.',[("Aceptar","accent")]).bind(on_dismiss=lambda *_:self.build())
        except Exception as e: popup('Usuario',e)
    def toggle_user(self,rid,active):
        set_user_active(rid,active); self.build()
    def save_zoho(self,z):
        for k,e in z.items(): set_config(k,e.text.strip())
        popup('Zoho','Credenciales guardadas localmente.')


class AtencionApp(App):
    admin_mode=False; admin_user=None
    def build(self):
        Window.clearcolor=BG
        self.sm=ScreenManager(transition=SlideTransition(duration=.15))
        self.screens={}
        for name,cls in [('setup',SetupScreen),('home',HomeScreen),('new',NewRecordScreen),('review',ReviewScreen),('import',ImportScreen),('settings',SettingsScreen),('admin',AdminScreen)]:
            screen=cls(name=name); self.screens[name]=screen; self.sm.add_widget(screen)
        if setup_complete(): self.go('home')
        else: self.go('setup')
        return self.sm
    def go(self,name):
        self.sm.current=name
    def home(self): self.go('home')
    def logout_admin(self): self.admin_mode=False; self.admin_user=None; self.go('settings')
    def protected_user(self,title):
        return self.admin_user if self.admin_mode and self.admin_user else None
    def request_login(self,title,callback):
        if self.admin_mode and self.admin_user:
            callback(self.admin_user); return
        body=BoxLayout(orientation='vertical',padding=dp(18),spacing=dp(8)); u=field(); p=field(password=True)
        body.add_widget(label(title,17,FG,True)); body.add_widget(label('Usuario',12,MUTED)); body.add_widget(u); body.add_widget(label('Contraseña',12,MUTED)); body.add_widget(p)
        row=BoxLayout(size_hint_y=None,height=dp(46),spacing=dp(8)); pop=Popup(title='',content=body,size_hint=(.9,.58),separator_height=0,background_color=SURFACE)
        def ok():
            user=authenticate(u.text,p.text)
            if not user: return popup('Acceso','Usuario o contraseña incorrectos.')
            pop.dismiss(); callback(user)
        row.add_widget(btn('Cancelar',lambda:(pop.dismiss(),callback(None)))); row.add_widget(btn('Continuar',ok,'accent')); body.add_widget(row); pop.open()
    def sync_zoho(self):
        self.request_login("Autenticación requerida para subir a Zoho", self._sync_with_user)

    def _sync_with_user(self, user):
        if not user: return
        def work():
            try:
                from sync_zoho import sync_pending
                result=sync_pending()
            except Exception as e: result=f"No fue posible sincronizar:\n{e}"
            Clock.schedule_once(lambda *_: popup("Sincronización", result),0)
        threading.Thread(target=work,daemon=True).start()

    def edit_record(self,rid):
        r=get_interaction(rid)
        if not r: return popup('Registro','No se encontró el registro.')
        body=BoxLayout(orientation='vertical',padding=dp(16),spacing=dp(7)); scroll=ScrollView(); inner=GridLayout(cols=1,spacing=dp(6),size_hint_y=None); inner.bind(minimum_height=inner.setter('height')); scroll.add_widget(inner); body.add_widget(scroll)
        edits={}
        for idx,key,title,multi in [(1,'cliente','Cliente',False),(2,'telefono','Teléfono',False),(13,'email','Correo',False),(5,'tipo','Tipo',False),(6,'solicitud','Solicitud',False),(7,'necesidades_adicionales','Necesidades adicionales',False),(8,'informacion','Información',True)]:
            inner.add_widget(label(title,11,MUTED));
            if key=='tipo': w=Spinner(text=r[idx] or 'Producto',values=['Producto','Servicio','Otro'],size_hint_y=None,height=dp(44),background_normal='',background_color=SURFACE2,color=FG)
            else: w=field(r[idx] or '',multiline=multi,h=dp(90) if multi else dp(44))
            inner.add_widget(w); edits[key]=w
        inner.add_widget(label('Estado de contacto',11,MUTED)); state=Spinner(text=r[12] or 'No contactado',values=ESTADOS_CONTACTO,size_hint_y=None,height=dp(44),background_normal='',background_color=SURFACE2,color=FG); inner.add_widget(state)
        inner.add_widget(label(f"Sucursal: {r[4]}  ·  Situación Zoho: {'Consulta' if (r[14] or 'Lead')=='Consulta' else 'Lead'}",11,MUTED))
        row=BoxLayout(size_hint_y=None,height=dp(48),spacing=dp(6)); body.add_widget(row); pop=Popup(title=f"Editar #{rid}",content=body,size_hint=(.95,.9),separator_height=0,background_color=SURFACE)
        def save():
            nuevo=state.text; actual=r[14] or 'Lead'; ruta=_route_for_record(edits['telefono'].text,edits['email'].text,nuevo)
            for k,w in edits.items(): update_interaction(rid,k,w.text)
            if actual=='Lead' and ruta=='Consulta':
                from sync_zoho import lead_to_consulta
                try: msg=lead_to_consulta(get_interaction(rid),nuevo)
                except Exception as e: return popup('Conversión',e)
            elif actual=='Consulta' and ruta=='Lead':
                from sync_zoho import consulta_to_lead
                try: msg=consulta_to_lead(get_interaction(rid),nuevo)
                except Exception as e: return popup('Reactivación',e)
            else:
                update_interaction(rid,'estado_contacto',nuevo)
                msg='Cambios guardados.'
            pop.dismiss(); popup('Actualizado',msg)
        row.add_widget(btn('Historial',lambda:self.show_history(rid),'secondary')); row.add_widget(btn('Borrar',lambda:self.delete_record(rid,pop),'danger')); row.add_widget(btn('Guardar cambios',save,'accent')); pop.open()

    def show_history(self,rid):
        rows=history_for_record(rid)
        if not rows: return popup('Historial','No hay cambios registrados.')
        text='\n'.join(f"{r[0]} · {r[1]} · {r[2]}" + (f" · {r[3]}: {r[4] or ''} → {r[5] or ''}" if r[3] else '') for r in rows[:30])
        popup('Historial de cambios',text,(('Cerrar','secondary'),),(.94,.72))

    def delete_record(self,rid,pop_edit=None):
        def after_login(user):
            if not user: return
            def work():
                try:
                    r=get_interaction(rid)
                    from sync_zoho import delete_remote_record
                    ok,detail=delete_remote_record(r) if r and r[10] else (True,None)
                    if not ok:
                        msg=f"No se pudo confirmar la eliminación en Zoho:\n{detail}"
                    else:
                        delete_interactions([rid]); msg='Registro eliminado correctamente.'
                except Exception as e: msg=f"No se pudo eliminar el registro:\n{e}"
                Clock.schedule_once(lambda *_: self._finish_delete(msg,pop_edit),0)
            threading.Thread(target=work,daemon=True).start()
        self.request_login('Autenticación requerida para borrar',after_login)

    def _finish_delete(self,msg,pop_edit):
        if pop_edit: pop_edit.dismiss()
        popup('Borrado',msg,(('Aceptar','accent'),)).bind(on_dismiss=lambda *_: self.go('review'))


if __name__ == '__main__':
    AtencionApp().run()

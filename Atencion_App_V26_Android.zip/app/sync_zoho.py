import requests
from datetime import datetime

from db import (
    pending_interactions, mark_synced, mark_consulta_synced, get_config,
    clear_zoho_link, update_interaction, mark_sync_started, mark_sync_finished,
)

CONSULTAS_MODULE = "Consultas"


def _zoho_datetime(fecha_str):
    if not fecha_str:
        return fecha_str
    try:
        naive = datetime.strptime(fecha_str, "%Y-%m-%d %H:%M:%S")
    except (ValueError, TypeError):
        return fecha_str
    aware = naive.astimezone()
    offset = aware.strftime("%z")
    if len(offset) == 5:
        offset = offset[:3] + ":" + offset[3:]
    return aware.strftime("%Y-%m-%dT%H:%M:%S") + offset


def _split_name(cliente):
    """Devuelve (First_Name, Last_Name), garantizando Last_Name."""
    cliente = (cliente or "").strip()
    if not cliente:
        return "", "Cliente"
    partes = cliente.split(None, 1)
    if len(partes) == 1:
        return "", partes[0]
    return partes[0], partes[1].strip()


def _required_config():
    vals = {k: (get_config(k, "") or "").strip() for k in (
        "ZOHO_CLIENT_ID", "ZOHO_CLIENT_SECRET", "ZOHO_REFRESH_TOKEN"
    )}
    missing = [k for k, v in vals.items() if not v]
    if missing:
        raise RuntimeError("Faltan credenciales de Zoho: " + ", ".join(missing))
    return vals


def _api_domain():
    api = (get_config("ZOHO_API_DOMAIN", "https://www.zohoapis.com") or "").strip().rstrip("/")
    for suffix in ("/crm/v8", "/crm/v7", "/crm/v6", "/crm"):
        if api.lower().endswith(suffix):
            api = api[:-len(suffix)].rstrip("/")
            break
    return api or "https://www.zohoapis.com"


def _accounts_domain():
    accounts = (get_config("ZOHO_ACCOUNTS_DOMAIN", "https://accounts.zoho.com") or "").strip().rstrip("/")
    for suffix in ("/oauth/v2", "/oauth"):
        if accounts.lower().endswith(suffix):
            accounts = accounts[:-len(suffix)].rstrip("/")
            break
    return accounts or "https://accounts.zoho.com"


def get_access_token():
    c = _required_config()
    resp = requests.post(_accounts_domain() + "/oauth/v2/token", data={
        "refresh_token": c["ZOHO_REFRESH_TOKEN"],
        "client_id": c["ZOHO_CLIENT_ID"],
        "client_secret": c["ZOHO_CLIENT_SECRET"],
        "grant_type": "refresh_token",
    }, timeout=20)
    try:
        data = resp.json()
    except ValueError:
        raise RuntimeError(f"Zoho devolvió una respuesta no válida ({resp.status_code}).")
    if not resp.ok or "access_token" not in data:
        raise RuntimeError(f"No se pudo obtener el token de Zoho: {data}")
    return data["access_token"]


def _lead_fields(r):
    adicionales = (r[7] or "").strip()
    necesidades = ", ".join(x.strip() for x in adicionales.split(",") if x.strip()) or (r[5] or "")
    first_name, last_name = _split_name(r[1])
    estado_contacto = r[12] if len(r) > 12 and r[12] else "No contactado"
    lead = {
        "Last_Name": last_name,
        "Phone": r[2] or "",
        "Lead_Status": estado_contacto,
        "Sucursal": r[4] or "",
        "Atendi": r[3] or "",
        "Necesidad": necesidades,
        "Solicitud": r[6] or "",
        "Description": (r[8] or "").strip(),
        "Date_Time": _zoho_datetime(r[9]),
    }
    if first_name:
        lead["First_Name"] = first_name
    if len(r) > 13 and (r[13] or "").strip():
        lead["Email"] = r[13].strip()
    return lead


def _lead_payload(r):
    return {"data": [_lead_fields(r)]}


def _consulta_fields(r):
    adicionales = (r[7] or "").strip()
    necesidad = ", ".join(x.strip() for x in adicionales.split(",") if x.strip()) or (r[5] or "")
    cliente = (r[1] or "").strip()
    return {
        "Name": cliente or "Sin datos",
        "Atendi": r[3] or "",
        "Description": (r[8] or "").strip(),
        "Necesidad": necesidad,
        "Solicitud": r[6] or "",
        "Sucursal": r[4] or "",
    }


def _consulta_payload(r):
    return {"data": [_consulta_fields(r)]}


def _headers(access):
    return {"Authorization": f"Zoho-oauthtoken {access}", "Content-Type": "application/json"}


def _success_id(data):
    if not isinstance(data, dict):
        return None
    items = data.get("data") or []
    if not items or not isinstance(items[0], dict):
        return None
    item = items[0]
    if item.get("status") != "success":
        return None
    return (item.get("details") or {}).get("id")


def _is_missing_record_error(item, status_code=None):
    """Indica que el registro remoto ya no existe.

    Zoho puede devolver este caso como HTTP 404 o como INVALID_DATA. En
    algunas respuestas el error está directamente en el objeto y en otras
    viene dentro de ``data[0]`` (como ``record not deleted``). Para una
    operación de BORRADO, ambas formas significan que la condición deseada
    ya se cumple: el registro no existe en Zoho.
    """
    if status_code == 404:
        return True
    if not isinstance(item, dict):
        return False

    candidates = [item]
    nested = item.get("data")
    if isinstance(nested, list):
        candidates.extend(x for x in nested if isinstance(x, dict))

    for candidate in candidates:
        code = str(candidate.get("code", "")).upper()
        message = str(candidate.get("message", "")).lower()
        details = candidate.get("details") or {}
        if not isinstance(details, dict):
            details = {}
        detail_message = str(details.get("message", "")).lower()
        combined = f"{message} {detail_message}"

        if code != "INVALID_DATA":
            continue

        missing_phrases = (
            "id given seems to be invalid",
            "record not deleted",
            "record not found",
            "record does not exist",
            "no record found",
        )
        if any(phrase in combined for phrase in missing_phrases):
            return True

    return False


def _is_invalid_id_error(item):
    """Respuesta específica de Zoho para un ID inválido en actualizaciones.

    Se mantiene separada de _is_missing_record_error porque una actualización
    y un borrado no tienen la misma semántica: al borrar, que el registro ya no
    exista equivale a éxito; al actualizar, debe quedar como pendiente.
    """
    if not isinstance(item, dict):
        return False
    return item.get("code") == "INVALID_DATA" and "id given seems to be invalid" in str(item.get("message", "")).lower()


def _normalize(value):
    return " ".join(str(value or "").strip().lower().split())


def _same_lead(remote, r):
    payload = _lead_fields(r)
    for field in ("Last_Name", "First_Name", "Phone", "Email", "Sucursal", "Atendi", "Solicitud"):
        if _normalize(remote.get(field)) != _normalize(payload.get(field)):
            return False
    return True


def _same_consulta(remote, r):
    payload = _consulta_fields(r)
    for field in ("Name", "Atendi", "Description", "Necesidad", "Solicitud", "Sucursal"):
        if _normalize(remote.get(field)) != _normalize(payload.get(field)):
            return False
    return True


def _search_candidates(module, r, access):
    """Busca candidatos para recuperar una alta que pudo completarse antes de un corte.

    Solo se usa en reintentos marcados como ambiguos. Zoho documenta el endpoint
    /{module}/search y los parámetros email/phone/criteria para búsquedas.\n    """
    api = _api_domain()
    params = None
    if module == "Leads":
        email = (r[13] or "").strip() if len(r) > 13 else ""
        phone = (r[2] or "").strip()
        if email:
            params = {"email": email}
        elif phone:
            params = {"phone": phone}
    else:
        name = _consulta_fields(r)["Name"]
        params = {"criteria": f"(Name:equals:{name})"}
    if not params:
        return []
    resp = requests.get(
        f"{api}/crm/v8/{module}/search",
        headers={"Authorization": f"Zoho-oauthtoken {access}"},
        params=params,
        timeout=25,
    )
    if resp.status_code == 204:
        return []
    try:
        data = resp.json()
    except ValueError:
        return []
    if not resp.ok:
        return []
    return data.get("data") or []


def _recover_ambiguous(r, access):
    module = CONSULTAS_MODULE if (r[14] or "Lead") == "Consulta" else "Leads"
    candidates = _search_candidates(module, r, access)
    matcher = _same_consulta if module == CONSULTAS_MODULE else _same_lead
    matches = [item for item in candidates if isinstance(item, dict) and matcher(item, r) and item.get("id")]
    if len(matches) != 1:
        return None
    return matches[0]["id"]


def sync_pending():
    # Solo se sincronizan registros de la sucursal configurada en esta computadora.
    current_branch = (get_config("sucursal", "") or "").strip()
    rows = pending_interactions(current_branch)
    if not rows:
        return "No hay registros pendientes de sincronizar."
    access = get_access_token()
    api = _api_domain()
    headers = _headers(access)
    ok = 0
    recovered = 0
    errors = []
    for r in rows:
        es_consulta = len(r) > 14 and (r[14] or "Lead") == "Consulta"
        module = CONSULTAS_MODULE if es_consulta else "Leads"
        url = f"{api}/crm/v8/{module}"
        payload = _consulta_payload(r) if es_consulta else _lead_payload(r)

        # Si una ejecución anterior alcanzó a enviar el POST pero se cortó antes
        # de guardar el ID local, primero intentamos recuperar ese registro.
        if len(r) > 16 and r[16]:
            try:
                recovered_id = _recover_ambiguous(r, access)
            except requests.RequestException:
                recovered_id = None
            if recovered_id:
                if es_consulta:
                    mark_consulta_synced(r[0], recovered_id)
                else:
                    mark_synced(r[0], recovered_id)
                recovered += 1
                continue

        mark_sync_started(r[0])
        try:
            resp = requests.post(url, headers=headers, json=payload, timeout=25)
            try:
                data = resp.json()
            except ValueError:
                data = {"raw": resp.text}
            zoho_id = _success_id(data)
            if resp.ok and zoho_id:
                if es_consulta:
                    mark_consulta_synced(r[0], zoho_id)
                else:
                    mark_synced(r[0], zoho_id)
                ok += 1
            else:
                mark_sync_finished(r[0])
                errors.append(f"ID {r[0]}: {data}")
        except requests.RequestException as e:
            # Se conserva sync_en_proceso=1 para que el siguiente intento pueda
            # buscar primero si Zoho alcanzó a crear el registro.
            errors.append(f"ID {r[0]}: error de red (se verificará antes de reintentar): {e}")

    total_ok = ok + recovered
    msg = f"Sincronizados: {total_ok}. Errores: {len(errors)}."
    if recovered:
        msg += f"\nRecuperados de un intento anterior: {recovered}."
    if errors:
        msg += "\n\n" + "\n".join(errors[:8])
    return msg


def _delete_record(module, record_id, access=None):
    if not record_id:
        return True, None
    if access is None:
        access = get_access_token()
    try:
        resp = requests.delete(
            f"{_api_domain()}/crm/v8/{module}/{record_id}",
            headers={"Authorization": f"Zoho-oauthtoken {access}"},
            timeout=25,
        )
        try:
            data = resp.json()
        except ValueError:
            data = {"raw": resp.text}
        # Primero comprobamos si el registro ya no existe. Esto debe hacerse
        # antes de interpretar el status HTTP porque algunas respuestas de
        # Zoho pueden llegar con cuerpo de error aunque la condición final
        # deseada para un borrado ya se cumpla.
        if _is_missing_record_error(data, resp.status_code):
            return True, data
        if resp.ok:
            if isinstance(data, dict) and data.get("code") and data.get("status") == "error":
                return False, data
            items = data.get("data", []) if isinstance(data, dict) else []
            if not items:
                return True, data
            if isinstance(items[0], dict) and items[0].get("status") == "success":
                return True, data
        # Si el ID ya no existe, desde el punto de vista de un borrado la
        # condición deseada ya se cumple: no queda un registro remoto.
        # Zoho puede responder INVALID_DATA/"record not deleted" aunque el
        # registro simplemente haya sido eliminado previamente desde Zoho;
        # ese caso ya fue resuelto arriba.
        return False, data
    except requests.RequestException as e:
        return False, {"error": str(e)}


def _local_set_route(record_id, tipo, lead_id=None, consulta_id=None, synchronized=False):
    from db import set_zoho_route
    set_zoho_route(record_id, tipo, synchronized, lead_id, consulta_id)


def lead_to_consulta(record, target_state="No habilitado"):
    if not record:
        raise ValueError("No se encontró el registro.")
    record_id = record[0]
    lead_id = record[11]
    if not lead_id:
        _local_set_route(record_id, "Consulta", synchronized=False)
        update_interaction(record_id, "estado_contacto", target_state)
        return "El registro quedó como Consulta y se creará como tal al subirlo."

    access = get_access_token()
    try:
        resp = requests.post(
            f"{_api_domain()}/crm/v8/{CONSULTAS_MODULE}",
            headers=_headers(access), json=_consulta_payload(record), timeout=25
        )
        try:
            data = resp.json()
        except ValueError:
            data = {"raw": resp.text}
        consulta_id = _success_id(data)
        if not resp.ok or not consulta_id:
            raise RuntimeError(f"No se pudo crear la Consulta: {data}")
    except requests.RequestException as e:
        raise RuntimeError(f"No se pudo crear la Consulta: {e}")

    deleted, delete_data = _delete_record("Leads", lead_id, access)
    if not deleted:
        rollback_ok, rollback_data = _delete_record(CONSULTAS_MODULE, consulta_id, access)
        detail = f" Detalle del borrado: {delete_data}."
        if not rollback_ok:
            detail += f" ATENCIÓN: tampoco se pudo revertir la Consulta creada: {rollback_data}."
        raise RuntimeError("La Consulta se creó, pero no se pudo retirar el Lead anterior." + detail)

    _local_set_route(record_id, "Consulta", synchronized=True, consulta_id=consulta_id)
    update_interaction(record_id, "estado_contacto", target_state)
    from db import _log_change
    _log_change(record_id, "Zoho", "Situación", "Lead", "Consulta", "Sistema")
    return "El Lead se convirtió en Consulta correctamente."


def consulta_to_lead(record, target_state=None):
    if not record:
        raise ValueError("No se encontró el registro.")
    record_id = record[0]
    consulta_id = record[15] if len(record) > 15 else None
    if not consulta_id:
        _local_set_route(record_id, "Lead", synchronized=False)
        if target_state:
            update_interaction(record_id, "estado_contacto", target_state)
        return "El registro quedó preparado como Lead y se creará como tal al subirlo."

    access = get_access_token()
    payload_record = list(record)
    if target_state:
        payload_record[12] = target_state
    try:
        resp = requests.post(
            f"{_api_domain()}/crm/v8/Leads",
            headers=_headers(access), json=_lead_payload(payload_record), timeout=25
        )
        try:
            data = resp.json()
        except ValueError:
            data = {"raw": resp.text}
        lead_id = _success_id(data)
        if not resp.ok or not lead_id:
            raise RuntimeError(f"No se pudo crear el nuevo Lead: {data}")
    except requests.RequestException as e:
        raise RuntimeError(f"No se pudo crear el nuevo Lead: {e}")

    deleted, delete_data = _delete_record(CONSULTAS_MODULE, consulta_id, access)
    if not deleted:
        rollback_ok, rollback_data = _delete_record("Leads", lead_id, access)
        detail = f" Detalle del borrado: {delete_data}."
        if not rollback_ok:
            detail += f" ATENCIÓN: tampoco se pudo revertir el Lead creado: {rollback_data}."
        raise RuntimeError("El nuevo Lead se creó, pero no se pudo retirar la Consulta anterior." + detail)

    _local_set_route(record_id, "Lead", synchronized=True, lead_id=lead_id)
    if target_state:
        update_interaction(record_id, "estado_contacto", target_state)
    from db import _log_change
    _log_change(record_id, "Zoho", "Situación", "Consulta", "Lead", "Sistema")
    return "La Consulta se reactivó como un Lead nuevo correctamente."


def update_records(rows):
    if not rows:
        return "No hay registros para actualizar."
    access = get_access_token()
    api = _api_domain()
    headers = _headers(access)
    ok = 0
    errors = []
    repaired = []
    for r in rows:
        es_consulta = len(r) > 14 and (r[14] or "Lead") == "Consulta"
        zoho_id = r[15] if es_consulta and len(r) > 15 else r[11]
        if not zoho_id:
            errors.append(f"ID {r[0]}: no tiene un registro asociado en Zoho.")
            continue
        module = CONSULTAS_MODULE if es_consulta else "Leads"
        payload = _consulta_payload(r) if es_consulta else _lead_payload(r)
        try:
            resp = requests.put(
                f"{api}/crm/v8/{module}/{zoho_id}", headers=headers,
                json=payload, timeout=25
            )
            try:
                data = resp.json()
            except ValueError:
                data = {"raw": resp.text}
            item = data.get("data", [{}])[0] if isinstance(data.get("data"), list) and data.get("data") else data
            if resp.ok and isinstance(item, dict) and item.get("status") == "success":
                if es_consulta:
                    mark_consulta_synced(r[0], zoho_id)
                else:
                    mark_synced(r[0], zoho_id)
                ok += 1
            elif _is_invalid_id_error(item) or _is_invalid_id_error(data):
                clear_zoho_link(r[0])
                repaired.append(r[0])
            else:
                errors.append(f"ID {r[0]}: {data}")
        except requests.RequestException as e:
            errors.append(f"ID {r[0]}: error de red: {e}")
    msg = f"Actualizados: {ok}. Errores: {len(errors)}."
    if repaired:
        msg += "\n\nSe reiniciaron a pendiente los registros con ID de Zoho inválido: " + ", ".join(map(str, repaired)) + "."
    if errors:
        msg += "\n\n" + "\n".join(errors[:8])
    return msg


def delete_remote_record(record, access=None):
    if not record or not record[10]:
        return True, None
    module = CONSULTAS_MODULE if (record[14] or "Lead") == "Consulta" else "Leads"
    remote_id = record[15] if module == CONSULTAS_MODULE else record[11]
    return _delete_record(module, remote_id, access)

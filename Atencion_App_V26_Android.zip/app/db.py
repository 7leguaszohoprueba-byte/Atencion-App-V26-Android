"""Base local SQLite de Atención V26 para Android.

La versión Android conserva el mismo modelo de datos y reglas de negocio que
la versión de escritorio, pero usa el almacenamiento privado de la app en vez
del Registro de Windows.
"""
import os
import sqlite3
from datetime import datetime
from pathlib import Path

try:
    from android.storage import app_storage_path
    DATA_DIR = Path(app_storage_path())
except Exception:
    DATA_DIR = Path.home() / ".atencion_v26"
DATA_DIR.mkdir(parents=True, exist_ok=True)
DB_PATH = DATA_DIR / "atencion.db"

SUCURSALES = [
    "Plan De Ayala", "Palmas", "Libramiento Sur", "Calzada Sumidero",
    "Niño de Atocha", "Tonalá", "San Cristóbal", "Comitán Mirador",
    "Comitán Plaza las Flores", "Sport Llantas Loma Bonita",
    "Sport Llantas Tire Boutique", "Mercado de los Ancianos"
]
ESTADOS_CONTACTO = [
    "No contactado", "Intento de contacto", "Contactar en el futuro",
    "Posible cliente perdido", "Contactado", "No habilitado"
]
_conn = None


def connect():
    global _conn
    if _conn is None:
        _conn = sqlite3.connect(str(DB_PATH), check_same_thread=False)
        _conn.row_factory = None
    return _conn


def init_db():
    conn = connect()
    cur = conn.cursor()
    cur.execute("""CREATE TABLE IF NOT EXISTS interacciones (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        cliente TEXT NOT NULL,
        telefono TEXT,
        atendio TEXT NOT NULL,
        sucursal TEXT NOT NULL,
        tipo TEXT NOT NULL,
        solicitud TEXT NOT NULL,
        necesidades_adicionales TEXT,
        informacion TEXT,
        fecha TEXT NOT NULL,
        sincronizado INTEGER NOT NULL DEFAULT 0,
        zoho_lead_id TEXT,
        estado_contacto TEXT NOT NULL DEFAULT 'No contactado',
        email TEXT,
        zoho_tipo TEXT NOT NULL DEFAULT 'Lead',
        zoho_consulta_id TEXT,
        sync_en_proceso INTEGER NOT NULL DEFAULT 0
    )""")
    cur.execute("""CREATE TABLE IF NOT EXISTS app_config (
        clave TEXT PRIMARY KEY, valor TEXT NOT NULL
    )""")
    cur.execute("""CREATE TABLE IF NOT EXISTS historial_cambios (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        registro_id INTEGER,
        fecha TEXT NOT NULL,
        usuario TEXT NOT NULL DEFAULT 'Sistema',
        accion TEXT NOT NULL,
        campo TEXT,
        valor_anterior TEXT,
        valor_nuevo TEXT
    )""")
    cur.execute("""CREATE TABLE IF NOT EXISTS usuarios (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        usuario TEXT UNIQUE NOT NULL,
        password_hash TEXT NOT NULL,
        rol TEXT NOT NULL CHECK(rol IN ('admin','gerente')),
        activo INTEGER NOT NULL DEFAULT 1,
        fecha_alta TEXT NOT NULL
    )""")
    conn.commit()


def get_config(key, default=None):
    row = connect().execute("SELECT valor FROM app_config WHERE clave=?", (key,)).fetchone()
    return row[0] if row and row[0] is not None else default


def set_config(key, value):
    connect().execute("INSERT INTO app_config(clave,valor) VALUES(?,?) ON CONFLICT(clave) DO UPDATE SET valor=excluded.valor", (key, str(value)))
    connect().commit()


def setup_complete():
    return bool(get_config("sucursal")) and get_config("setup_complete") == "1"


def create_user(username, password_hash, role="gerente"):
    conn = connect()
    conn.execute("INSERT INTO usuarios(usuario,password_hash,rol,activo,fecha_alta) VALUES(?,?,?,?,?)",
                 (username, password_hash, role, 1, datetime.now().strftime("%Y-%m-%d %H:%M:%S")))
    conn.commit()


def get_user(username):
    return connect().execute("SELECT id,usuario,password_hash,rol,activo FROM usuarios WHERE usuario=?", (username,)).fetchone()


def list_users():
    return connect().execute("SELECT id,usuario,rol,activo,fecha_alta FROM usuarios ORDER BY usuario").fetchall()


def set_user_active(user_id, active):
    connect().execute("UPDATE usuarios SET activo=? WHERE id=?", (1 if active else 0, user_id)); connect().commit()


def _route_for_record(phone="", email="", estado_contacto="No contactado", sin_datos=False):
    if sin_datos or (estado_contacto or "").strip() == "No habilitado":
        return "Consulta"
    if not (str(phone or "").strip() or str(email or "").strip()):
        return "Consulta"
    return "Lead"


def set_zoho_route(record_id, zoho_tipo, synchronized=False, lead_id=None, consulta_id=None):
    tipo = "Consulta" if zoho_tipo == "Consulta" else "Lead"
    connect().execute("""UPDATE interacciones SET sincronizado=?, zoho_lead_id=?, zoho_consulta_id=?, zoho_tipo=?, sync_en_proceso=0 WHERE id=?""",
                      (1 if synchronized else 0, lead_id if tipo == "Lead" else None, consulta_id if tipo == "Consulta" else None, tipo, record_id))
    connect().commit()


def save_interaction(d):
    conn = connect()
    estado = d.get("estado_contacto", "No contactado") or "No contactado"
    tipo_zoho = _route_for_record(d.get("telefono"), d.get("email"), estado, d.get("sin_datos", False))
    fecha = d.get("fecha") or datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    cur = conn.execute("""INSERT INTO interacciones
        (cliente,telefono,atendio,sucursal,tipo,solicitud,necesidades_adicionales,informacion,fecha,email,zoho_tipo,estado_contacto)
        VALUES(?,?,?,?,?,?,?,?,?,?,?,?)""", (
        d.get("cliente", ""), d.get("telefono", ""), d["atendio"], d["sucursal"], d["tipo"], d["solicitud"],
        d.get("necesidades", ""), d.get("informacion", ""), fecha, d.get("email", ""), tipo_zoho, estado))
    conn.commit(); rid = cur.lastrowid
    _log_change(rid, "Creado", None, None, "Registro creado", d.get("usuario", "Sistema"))
    return rid


def all_interactions(sucursal=None):
    q = """SELECT id,cliente,telefono,atendio,sucursal,tipo,solicitud,necesidades_adicionales,informacion,fecha,
        sincronizado,zoho_lead_id,estado_contacto,email,zoho_tipo,zoho_consulta_id,sync_en_proceso
        FROM interacciones"""
    if sucursal:
        return connect().execute(q + " WHERE sucursal=? ORDER BY id DESC", (sucursal,)).fetchall()
    return connect().execute(q + " ORDER BY id DESC").fetchall()


def pending_interactions(sucursal=None):
    q = """SELECT id,cliente,telefono,atendio,sucursal,tipo,solicitud,necesidades_adicionales,informacion,fecha,
        sincronizado,zoho_lead_id,estado_contacto,email,zoho_tipo,zoho_consulta_id,sync_en_proceso
        FROM interacciones WHERE sincronizado=0"""
    if sucursal:
        return connect().execute(q + " AND sucursal=? ORDER BY id ASC", (sucursal,)).fetchall()
    return connect().execute(q + " ORDER BY id ASC").fetchall()


def mark_synced(record_id, zoho_id=None):
    if not zoho_id: raise ValueError("Zoho no devolvió el identificador del Lead.")
    connect().execute("UPDATE interacciones SET sincronizado=1,zoho_lead_id=?,zoho_tipo='Lead',zoho_consulta_id=NULL,sync_en_proceso=0 WHERE id=?", (zoho_id, record_id)); connect().commit()


def mark_consulta_synced(record_id, consulta_id=None):
    if not consulta_id: raise ValueError("Zoho no devolvió el identificador de la Consulta.")
    connect().execute("UPDATE interacciones SET sincronizado=1,zoho_lead_id=NULL,zoho_tipo='Consulta',zoho_consulta_id=?,sync_en_proceso=0 WHERE id=?", (consulta_id, record_id)); connect().commit()


def clear_zoho_link(record_id):
    row = connect().execute("SELECT zoho_tipo FROM interacciones WHERE id=?", (record_id,)).fetchone()
    tipo = "Consulta" if row and row[0] == "Consulta" else "Lead"
    connect().execute("UPDATE interacciones SET sincronizado=0,zoho_lead_id=NULL,zoho_consulta_id=NULL,zoho_tipo=?,sync_en_proceso=0 WHERE id=?", (tipo, record_id)); connect().commit()


def mark_sync_started(record_id):
    connect().execute("UPDATE interacciones SET sync_en_proceso=1 WHERE id=?", (record_id,)); connect().commit()


def mark_sync_finished(record_id):
    connect().execute("UPDATE interacciones SET sync_en_proceso=0 WHERE id=?", (record_id,)); connect().commit()


def get_sync_state(record_id):
    row = connect().execute("SELECT sync_en_proceso FROM interacciones WHERE id=?", (record_id,)).fetchone(); return bool(row[0]) if row else False


def _log_change(record_id, accion, campo=None, anterior=None, nuevo=None, usuario="Sistema"):
    connect().execute("""INSERT INTO historial_cambios(registro_id,fecha,usuario,accion,campo,valor_anterior,valor_nuevo) VALUES(?,?,?,?,?,?,?)""",
                      (record_id, datetime.now().strftime("%Y-%m-%d %H:%M:%S"), usuario or "Sistema", accion, campo,
                       None if anterior is None else str(anterior), None if nuevo is None else str(nuevo)))
    connect().commit()


def history_for_record(record_id):
    return connect().execute("SELECT fecha,usuario,accion,campo,valor_anterior,valor_nuevo FROM historial_cambios WHERE registro_id=? ORDER BY id DESC", (record_id,)).fetchall()


def update_interaction(record_id, field, value, usuario="Sistema"):
    allowed = {"cliente", "telefono", "email", "tipo", "solicitud", "necesidades_adicionales", "informacion", "estado_contacto"}
    if field not in allowed: raise ValueError("Campo no editable")
    row = connect().execute(f"SELECT {field} FROM interacciones WHERE id=?", (record_id,)).fetchone()
    if not row: raise ValueError("Registro no encontrado")
    anterior = row[0]
    if str(anterior or "") == str(value or ""): return
    connect().execute(f"UPDATE interacciones SET {field}=? WHERE id=?", (value, record_id)); connect().commit()
    _log_change(record_id, "Modificado", field, anterior, value, usuario)


def get_interaction(record_id):
    return connect().execute("""SELECT id,cliente,telefono,atendio,sucursal,tipo,solicitud,necesidades_adicionales,informacion,fecha,
        sincronizado,zoho_lead_id,estado_contacto,email,zoho_tipo,zoho_consulta_id,sync_en_proceso
        FROM interacciones WHERE id=?""", (record_id,)).fetchone()


def delete_interactions(record_ids):
    ids = list(record_ids)
    if not ids: return
    conn = connect(); ph = ",".join("?" * len(ids))
    conn.execute(f"DELETE FROM interacciones WHERE id IN ({ph})", ids); conn.commit()


def save_imported_rows(rows, default_sucursal):
    """Inserta filas ya mapeadas. La sucursal nunca proviene del Excel."""
    conn = connect(); imported = 0; skipped = 0; errors = []
    for rownum, values in rows:
        if not any(str(values.get(k, "") or "").strip() for k in values): continue
        if not values.get("atendio", "").strip() or not values.get("solicitud", "").strip():
            skipped += 1
            if len(errors) < 20: errors.append(f"Fila {rownum}: falta Atendió o Solicitud.")
            continue
        tipo = values.get("tipo") if values.get("tipo") in ("Producto", "Servicio", "Otro") else "Producto"
        estado = values.get("estado_contacto") if values.get("estado_contacto") in ESTADOS_CONTACTO else "No contactado"
        fecha = values.get("fecha") or datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        zoho_tipo = _route_for_record(values.get("telefono"), values.get("email"), estado)
        cur = conn.execute("""INSERT INTO interacciones
            (cliente,telefono,atendio,sucursal,tipo,solicitud,necesidades_adicionales,informacion,fecha,email,zoho_tipo,estado_contacto)
            VALUES(?,?,?,?,?,?,?,?,?,?,?,?)""", (
            values.get("cliente", ""), values.get("telefono", ""), values.get("atendio", ""), default_sucursal,
            tipo, values.get("solicitud", ""), values.get("necesidades", ""), values.get("informacion", ""),
            fecha, values.get("email", ""), zoho_tipo, estado))
        rid = cur.lastrowid
        conn.execute("INSERT INTO historial_cambios(registro_id,fecha,usuario,accion,valor_nuevo) VALUES(?,?,?,?,?)",
                     (rid, datetime.now().strftime("%Y-%m-%d %H:%M:%S"), "Sistema", "Importado", "Registro importado desde Excel"))
        imported += 1
    conn.commit(); return imported, skipped, errors

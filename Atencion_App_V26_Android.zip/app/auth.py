import os, hashlib, hmac, base64
from db import get_user, create_user

ITERATIONS = 310_000


def hash_password(password, salt=None):
    if salt is None: salt=os.urandom(16)
    digest=hashlib.pbkdf2_hmac("sha256", password.encode("utf-8"), salt, ITERATIONS)
    return "pbkdf2_sha256${}${}${}".format(ITERATIONS, base64.b64encode(salt).decode(), base64.b64encode(digest).decode())


def verify_password(password, stored):
    try:
        alg, iters, salt_b64, digest_b64 = stored.split("$",3)
        salt=base64.b64decode(salt_b64); expected=base64.b64decode(digest_b64)
        got=hashlib.pbkdf2_hmac("sha256", password.encode("utf-8"), salt, int(iters))
        return hmac.compare_digest(got, expected)
    except Exception:
        return False


def authenticate(username, password):
    row=get_user(username.strip())
    if not row or not row[4]: return None
    if verify_password(password, row[2]):
        return {"id":row[0],"usuario":row[1],"rol":row[3]}
    return None
"""Puentes Android para abrir/guardar documentos mediante Storage Access Framework."""
from pathlib import Path

_REQUEST_OPEN = 48127
_REQUEST_SAVE = 48128


def _imports():
    from android import activity
    from jnius import autoclass
    return activity, autoclass


def open_xlsx(callback):
    try:
        activity, autoclass = _imports()
    except Exception:
        callback(None); return
    Intent = autoclass('android.content.Intent')
    PythonActivity = autoclass('org.kivy.android.PythonActivity')
    intent = Intent(Intent.ACTION_OPEN_DOCUMENT)
    intent.addCategory(Intent.CATEGORY_OPENABLE)
    intent.setType('application/vnd.openxmlformats-officedocument.spreadsheetml.sheet')

    def on_result(request_code, result_code, data):
        if request_code != _REQUEST_OPEN:
            return
        try: activity.unbind(on_activity_result=on_result)
        except Exception: pass
        if result_code != -1 or data is None:
            callback(None); return
        try:
            uri = data.getData()
            resolver = PythonActivity.mActivity.getContentResolver()
            stream = resolver.openInputStream(uri)
            path = Path(PythonActivity.mActivity.getCacheDir().getAbsolutePath()) / 'atencion_importacion.xlsx'
            with open(path, 'wb') as out:
                buf = bytearray(65536)
                while True:
                    n = stream.read(buf)
                    if n <= 0: break
                    out.write(buf[:n])
            stream.close()
            callback(str(path))
        except Exception:
            callback(None)
    activity.bind(on_activity_result=on_result)
    PythonActivity.mActivity.startActivityForResult(intent, _REQUEST_OPEN)


def save_bytes(filename, data, mime, callback):
    try:
        activity, autoclass = _imports()
    except Exception:
        callback(None); return
    Intent = autoclass('android.content.Intent')
    PythonActivity = autoclass('org.kivy.android.PythonActivity')
    intent = Intent(Intent.ACTION_CREATE_DOCUMENT)
    intent.addCategory(Intent.CATEGORY_OPENABLE)
    intent.setType(mime)
    intent.putExtra(Intent.EXTRA_TITLE, filename)

    def on_result(request_code, result_code, uri_intent):
        if request_code != _REQUEST_SAVE:
            return
        try: activity.unbind(on_activity_result=on_result)
        except Exception: pass
        if result_code != -1 or uri_intent is None:
            callback(False); return
        try:
            uri = uri_intent.getData()
            resolver = PythonActivity.mActivity.getContentResolver()
            stream = resolver.openOutputStream(uri)
            stream.write(data)
            stream.flush(); stream.close()
            callback(True)
        except Exception:
            callback(False)
    activity.bind(on_activity_result=on_result)
    PythonActivity.mActivity.startActivityForResult(intent, _REQUEST_SAVE)
